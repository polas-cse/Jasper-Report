package com.doer.erp.get.exam.markseet.report.by.student.id.v1.entity;


import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;


public class ExamResultMark {
	private String subjectCode;
	private String textbookEn;
	private String textbookBn;
    private BigDecimal totalMarks = BigDecimal.ZERO;
    private BigDecimal obtainedMarks= BigDecimal.ZERO;
    private String letterGrade;
    private BigDecimal gradePoint= BigDecimal.ZERO;
    private BigDecimal totalGradePoint= BigDecimal.ZERO;
	public String getSubjectCode() {
		return subjectCode;
	}
	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}
	public String getTextbookEn() {
		return textbookEn;
	}
	public void setTextbookEn(String textbookEn) {
		this.textbookEn = textbookEn;
	}
	public String getTextbookBn() {
		return textbookBn;
	}
	public void setTextbookBn(String textbookBn) {
		this.textbookBn = textbookBn;
	}
	public BigDecimal getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(BigDecimal totalMarks) {
		this.totalMarks = totalMarks;
	}
	public BigDecimal getObtainedMarks() {
		return obtainedMarks;
	}
	public void setObtainedMarks(BigDecimal obtainedMarks) {
		this.obtainedMarks = obtainedMarks;
	}
	public String getLetterGrade() {
		return letterGrade;
	}
	public void setLetterGrade(String letterGrade) {
		this.letterGrade = letterGrade;
	}
	public BigDecimal getGradePoint() {
		return gradePoint;
	}
	public void setGradePoint(BigDecimal gradePoint) {
		this.gradePoint = gradePoint;
	}
	public BigDecimal getTotalGradePoint() {
		return totalGradePoint;
	}
	public void setTotalGradePoint(BigDecimal totalGradePoint) {
		this.totalGradePoint = totalGradePoint;
	}
    
    
}
