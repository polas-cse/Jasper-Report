package com.doer.erp.get.exam.markseet.report.by.student.id.v1.request;

import com.doer.erp.core.util.Constant;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Data
@Getter
@Setter
@JsonSerialize
@JsonDeserialize
@NoArgsConstructor
@AllArgsConstructor
public class GetExamMarksheetReportByStudentIdV1RequestBody {
	
	private String lang, oid, instituteOid, examOid, sessionOid, studentId;
	
	@Override
	public String toString() {
		return Constant.print(this);
	}

}
