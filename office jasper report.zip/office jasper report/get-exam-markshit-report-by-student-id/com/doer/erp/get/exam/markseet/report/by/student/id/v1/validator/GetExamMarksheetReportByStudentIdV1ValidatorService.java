package com.doer.erp.get.exam.markseet.report.by.student.id.v1.validator;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.doer.erp.get.exam.markseet.report.by.student.id.v1.request.GetExamMarksheetReportByStudentIdV1Request;

@Service
public class GetExamMarksheetReportByStudentIdV1ValidatorService {

	public void validateGetExamRoutineByExamOidRequest(GetExamMarksheetReportByStudentIdV1Request request) {

		List<String> errors = new ArrayList<String>();

		if (request == null) {
			errors.add("Bad Formated Request");
		}
		

	}

}