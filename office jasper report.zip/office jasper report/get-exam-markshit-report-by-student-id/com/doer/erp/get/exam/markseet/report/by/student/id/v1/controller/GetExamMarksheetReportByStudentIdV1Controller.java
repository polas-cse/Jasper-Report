package com.doer.erp.get.exam.markseet.report.by.student.id.v1.controller;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.doer.erp.base.exception.ExceptionHandlerUtil;
import com.doer.erp.core.util.Api;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.request.GetExamMarksheetReportByStudentIdV1Request;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.service.GetExamMarksheetReportByStudentIdV1Service;

import lombok.extern.slf4j.Slf4j;

@CrossOrigin(origins = Api.SERVER_BASE)
@RestController
@RequestMapping(Api.API_BASE)
@Slf4j
public class GetExamMarksheetReportByStudentIdV1Controller {

	@Autowired
	private GetExamMarksheetReportByStudentIdV1Service service;
	
	@PostMapping(path = Api.EXAM_MARKSHIT_BY_STUDENT_ID)
	//@PostMapping(path = Api.GET_EXAM_RESULT_BY_TEXT_BOOK_REPORT)
	public void getExamRoutineByExamOid(
			@RequestBody GetExamMarksheetReportByStudentIdV1Request request, HttpServletResponse response,
			@RequestHeader(name = "Request-Id", required = false) String requestId,
			@RequestHeader(name = "Request-Timeout-In-Seconds", required = false) String requestTimeoutInSeconds,
			@RequestHeader(name = "Request-Time", required = false) @Pattern(regexp = "(19|20)[0-9][0-9]-(0[0-9]|1[0-2])-(0[1-9]|([12][0-9]|3[01]))T([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9].([0-9]{3,6})Z", message = "must match yyyy-MM-ddTHH:mm:ss.SSSSSSZ") String requestTime,
			@RequestHeader(name = "Trace-Id", required = false) String traceId

	) throws Exception {
		try {
			//String url = Api.API_BASE.concat(Api.GET_EXAM_RESULT_BY_TEXT_BOOK_OID);
			String url = Api.API_BASE.concat(Api.GET_EXAM_RESULT_BY_TEXT_BOOK_REPORT);
			log.debug("API URL:{}", url);
			log.info(
					"....Get Exam Routine By Exam Oid Request Recieved At Controller....");

			response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", String.format("inline; filename=Exam_Routine.pdf"));
			service.generatePdfFile(request, response.getOutputStream());
			log.info("Resource : {}", url);
		} catch (ExceptionHandlerUtil ex) {
			log.error(ex.getMessage(), ex);
			throw new ResponseStatusException(ex.getCode(), ex.getMessage(), ex);
		}
	}

}
