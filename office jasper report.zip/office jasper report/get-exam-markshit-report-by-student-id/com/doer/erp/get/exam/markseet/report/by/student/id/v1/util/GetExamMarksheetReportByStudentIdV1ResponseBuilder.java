package com.doer.erp.get.exam.markseet.report.by.student.id.v1.util;

import java.util.Date;

import com.doer.erp.core.util.ResponseHeader;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.models.GetExamMarksheetReportByStudentIdV1Model;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.request.GetExamMarksheetReportByStudentIdV1Request;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.response.GetExamMarksheetReportByStudentIdV1Response;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.response.GetExamMarksheetReportByStudentIdV1ResponseBody;

public class GetExamMarksheetReportByStudentIdV1ResponseBuilder {

	public static GetExamMarksheetReportByStudentIdV1Response buildGetApplicationByApplicationTrackingIdResponse(
			GetExamMarksheetReportByStudentIdV1Request request, GetExamMarksheetReportByStudentIdV1Model entity,
			String responseCode, String responseStatus, String message) {

		GetExamMarksheetReportByStudentIdV1Response response = new GetExamMarksheetReportByStudentIdV1Response();

		ResponseHeader responseHeader = new ResponseHeader();
		responseHeader.setRequestId(request.getHeader().getRequestId());
        responseHeader.setRequestDateTime(request.getHeader().getRequestDateTime());
		responseHeader.setResponseDateTime(new Date());
		responseHeader.setResponseCode(responseCode);
		responseHeader.setStatus(responseStatus);
		responseHeader.setMessage(message);
		response.setHeader(responseHeader);

		GetExamMarksheetReportByStudentIdV1ResponseBody responseBody = new GetExamMarksheetReportByStudentIdV1ResponseBody();
//		responseBody.setOid(entity.getOid());
		response.setBody(responseBody);
		return response;

	}
	
}
