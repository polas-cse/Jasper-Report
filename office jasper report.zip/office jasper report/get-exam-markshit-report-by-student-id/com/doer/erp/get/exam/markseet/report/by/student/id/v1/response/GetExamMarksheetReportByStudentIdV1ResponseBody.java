package com.doer.erp.get.exam.markseet.report.by.student.id.v1.response;

import java.util.List;

import com.doer.erp.get.exam.markseet.report.by.student.id.v1.entity.ExamResultMark;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class GetExamMarksheetReportByStudentIdV1ResponseBody {

	private String nameEn;
	private String nameBn;
	private String rollNumber;
	private String fatherNameEn;
	private String fatherNameBn;
	private String motherNameEn;
	private String motherNameBn;
	private String examEn;
	private String examBn;
    private String sessionEn;
    private String sessionBn;
    private String versionEn;
    private String versionBn;
    private String shiftEn; 
    private String shiftBn;
    private String sectionEn;
    private String sectionBn;
    
    
    private List<ExamResultMark> resultMarksList;

}
