package com.doer.erp.get.exam.markseet.report.by.student.id.v1.request;

import com.doer.erp.core.util.RequestHeader;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class GetExamMarksheetReportByStudentIdV1Request {

    private RequestHeader header;
    private GetExamMarksheetReportByStudentIdV1RequestBody body;

}
