package com.doer.erp.get.exam.markseet.report.by.student.id.v1.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.doer.erp.base.exception.ExceptionHandlerUtil;
import com.doer.erp.core.util.Table;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.entity.ExamResultMark;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.models.GetExamMarksheetReportByStudentIdV1Model;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.request.GetExamMarksheetReportByStudentIdV1Request;
import com.doer.erp.report.model.InstituteReportModel;

@Service
public class GetExamMarksheetReportByStudentIdV1Dao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@SuppressWarnings("deprecation")
	public InstituteReportModel getInstituteInfo(String instituteOid)
			throws ExceptionHandlerUtil {
		// @formatter:off
	    	String sql = "select i.name_en, i.name_bn "
	    			+ " from  " + Table.INSTITUTE + " i "
	    			+ " where i.oid = ? " ;
		  // @formatter:on
		return (InstituteReportModel) jdbcTemplate.queryForObject(sql, new Object[] { instituteOid },
			new RowMapper<InstituteReportModel>() {
				@Override
				public InstituteReportModel mapRow(ResultSet rs, int rwNumber) throws SQLException {
					InstituteReportModel applicationEntity = new InstituteReportModel();

					applicationEntity.setNameEn(rs.getString("name_en"));
					applicationEntity.setNameBn(rs.getString("name_bn"));

					return applicationEntity;
				}
			}
		);
	}

	
public GetExamMarksheetReportByStudentIdV1Model loodExamResult(GetExamMarksheetReportByStudentIdV1Request request) throws Exception{
		
	GetExamMarksheetReportByStudentIdV1Model examResult = new GetExamMarksheetReportByStudentIdV1Model();
		
		try {
			String sqlForExamResult = "select distinct s.name_en, s.name_bn, s.roll_number, s.father_name_en, s.father_name_bn, s.mother_name_en, s.mother_name_bn, "
					+ "e.name_en examEn, e.name_bn examBn, inss.name_en sessionEn, inss.name_bn sessionBn, "
					+ "iv.name_en versionEn, iv.name_Bn versionBn, shift.name_en shiftEn, shift.name_bn shiftBn, ics.name_en sectionEn, ics.name_bn sectionBn "
					+ "from "+Table.EXAM_RESULT+" er "
					+ "left join "+Table.EXAM+" e on e.oid = er.exam_oid "
					+ "left join "+Table.INSTITUTE_SESSION+" inss on inss.oid = er.institute_session_oid "
					+ "left join "+Table.EXAM_RESULT_DETAILS+" erd on erd.exam_result_oid = er.oid "
					+ "left join "+Table.INSTITUTE_VERSION+" iv on iv.oid = erd.institute_version_oid "
					+ "left join "+Table.INSTITUTE_SHIFT+" shift on shift.oid = erd.institute_shift_oid "
					+ "left join "+Table.EXAM_RESULT_MARKS+" erm on erm.exam_result_detail_oid = erd.oid "
					+ "left join "+Table.STUDENT+" s on s.student_id = erm.student_id "
					+ "left join "+Table.INSTITUTE_CLASS_SECTION+" ics on ics.oid = s.institute_class_section_oid  "
					+ " where e.institute_oid = '"+request.getBody().getInstituteOid()+"' "
					+ " and e.oid = '"+request.getBody().getExamOid()+"' "
					+ " and e.institute_session_oid = '"+request.getBody().getSessionOid()+"' "
					+ " and s.student_id = '"+request.getBody().getStudentId()+"'";
			
			String sqlForExamMarks = "select ict.name_en textbookEn, ict.name_bn textbookBn, erm.total_marks, "
					+ " erm.obtained_marks, erm.letter_grade, erm.grade_point, ict.subject_code "
					+ " from "+Table.EXAM_RESULT_MARKS+" erm "
					+ " left join "+Table.INSTITUTE_CLASS_TEXTBOOK+" ict on ict.oid = erm.class_textbook_oid "
					+ " left join "+Table.STUDENT+" s on s.student_id = erm.student_id "
					+ " left join "+Table.EXAM+" e on e.oid = erm.exam_oid "
					+ " where e.oid = '"+request.getBody().getExamOid()+"' "
					+ " and e.institute_oid = '"+request.getBody().getInstituteOid()+"' "
					+ " and e.institute_session_oid = '"+request.getBody().getSessionOid()+"' "
					+ " and s.student_id = '"+request.getBody().getStudentId()+"'";
			

			List<Map<String, Object>> rowsForExam = jdbcTemplate.queryForList(sqlForExamResult);
			List<Map<String, Object>> rowsForExamMarks = jdbcTemplate.queryForList(sqlForExamMarks);
			
			for(Map<String, Object> row:rowsForExam){
				examResult.setNameEn((String) row.get("name_en"));
				examResult.setNameBn((String) row.get("name_bn"));
				examResult.setRollNumber((String) row.get("roll_number"));
				examResult.setFatherNameEn((String) row.get("father_name_en"));
				examResult.setFatherNameBn((String) row.get("father_name_bn"));
				examResult.setMotherNameEn((String) row.get("mother_name_en"));
				examResult.setMotherNameBn((String) row.get("mother_name_bn"));
				examResult.setExamEn((String) row.get("examEn"));
				examResult.setExamBn((String) row.get("examBn"));
				examResult.setSessionEn((String) row.get("sessionEn"));
				examResult.setSessionBn((String) row.get("sessionBn"));
				examResult.setVersionEn((String) row.get("versionEn"));
				examResult.setVersionBn((String) row.get("versionBn"));
				examResult.setShiftEn((String) row.get("shiftEn"));
				examResult.setShiftBn((String) row.get("shiftBn"));
				examResult.setSectionEn((String) row.get("sectionEn"));
				examResult.setSectionBn((String) row.get("sectionBn"));

				break;
			}

			List<ExamResultMark> resultList = new ArrayList<>();
			for(Map<String, Object> row:rowsForExamMarks){
				ExamResultMark result = new ExamResultMark();
				result.setTextbookEn((String) row.get("textbookEn"));
				result.setTextbookBn((String) row.get("textbookBn"));
				result.setTotalMarks((BigDecimal) row.get("total_marks"));
				result.setObtainedMarks((BigDecimal) row.get("total_marks"));
				result.setLetterGrade((String) row.get("letter_grade"));
				result.setGradePoint((BigDecimal) row.get("grade_point"));
				result.setSubjectCode((String) row.get("subject_code"));

				resultList.add(result);
			}
			examResult.setResultMarksList(resultList);

			
						
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return examResult;
	}
}
