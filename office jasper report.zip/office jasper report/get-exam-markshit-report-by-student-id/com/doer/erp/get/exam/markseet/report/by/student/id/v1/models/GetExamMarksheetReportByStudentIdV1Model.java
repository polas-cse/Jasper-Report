package com.doer.erp.get.exam.markseet.report.by.student.id.v1.models;

import java.util.List;

import com.doer.erp.get.exam.markseet.report.by.student.id.v1.entity.ExamResultMark;

import lombok.Data;
import lombok.NoArgsConstructor;


public class GetExamMarksheetReportByStudentIdV1Model {

	private String nameEn;
	private String nameBn;
	private String rollNumber;
	private String fatherNameEn;
	private String fatherNameBn;
	private String motherNameEn;
	private String motherNameBn;
	private String examEn;
	private String examBn;
    private String sessionEn;
    private String sessionBn;
    private String versionEn;
    private String versionBn;
    private String shiftEn; 
    private String shiftBn;
    private String sectionEn;
    private String sectionBn;
    
    
    private List<ExamResultMark> resultMarksList;


	public String getNameEn() {
		return nameEn;
	}


	public void setNameEn(String nameEn) {
		this.nameEn = nameEn;
	}


	public String getNameBn() {
		return nameBn;
	}


	public void setNameBn(String nameBn) {
		this.nameBn = nameBn;
	}


	public String getRollNumber() {
		return rollNumber;
	}


	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}


	public String getFatherNameEn() {
		return fatherNameEn;
	}


	public void setFatherNameEn(String fatherNameEn) {
		this.fatherNameEn = fatherNameEn;
	}


	public String getFatherNameBn() {
		return fatherNameBn;
	}


	public void setFatherNameBn(String fatherNameBn) {
		this.fatherNameBn = fatherNameBn;
	}


	public String getMotherNameEn() {
		return motherNameEn;
	}


	public void setMotherNameEn(String motherNameEn) {
		this.motherNameEn = motherNameEn;
	}


	public String getMotherNameBn() {
		return motherNameBn;
	}


	public void setMotherNameBn(String motherNameBn) {
		this.motherNameBn = motherNameBn;
	}


	public String getExamEn() {
		return examEn;
	}


	public void setExamEn(String examEn) {
		this.examEn = examEn;
	}


	public String getExamBn() {
		return examBn;
	}


	public void setExamBn(String examBn) {
		this.examBn = examBn;
	}


	public String getSessionEn() {
		return sessionEn;
	}


	public void setSessionEn(String sessionEn) {
		this.sessionEn = sessionEn;
	}


	public String getSessionBn() {
		return sessionBn;
	}


	public void setSessionBn(String sessionBn) {
		this.sessionBn = sessionBn;
	}


	public String getVersionEn() {
		return versionEn;
	}


	public void setVersionEn(String versionEn) {
		this.versionEn = versionEn;
	}


	public String getVersionBn() {
		return versionBn;
	}


	public void setVersionBn(String versionBn) {
		this.versionBn = versionBn;
	}


	public String getShiftEn() {
		return shiftEn;
	}


	public void setShiftEn(String shiftEn) {
		this.shiftEn = shiftEn;
	}


	public String getShiftBn() {
		return shiftBn;
	}


	public void setShiftBn(String shiftBn) {
		this.shiftBn = shiftBn;
	}


	public String getSectionEn() {
		return sectionEn;
	}


	public void setSectionEn(String sectionEn) {
		this.sectionEn = sectionEn;
	}


	public String getSectionBn() {
		return sectionBn;
	}


	public void setSectionBn(String sectionBn) {
		this.sectionBn = sectionBn;
	}


	public List<ExamResultMark> getResultMarksList() {
		return resultMarksList;
	}


	public void setResultMarksList(List<ExamResultMark> resultMarksList) {
		this.resultMarksList = resultMarksList;
	}

}
