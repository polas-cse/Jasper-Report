package com.doer.erp.get.exam.markseet.report.by.student.id.v1.response;

import com.doer.erp.core.util.ResponseHeader;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class GetExamMarksheetReportByStudentIdV1Response {

	private ResponseHeader header;
	private GetExamMarksheetReportByStudentIdV1ResponseBody body;

}
