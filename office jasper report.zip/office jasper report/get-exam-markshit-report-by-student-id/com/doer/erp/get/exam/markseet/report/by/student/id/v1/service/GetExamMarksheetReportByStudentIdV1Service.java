package com.doer.erp.get.exam.markseet.report.by.student.id.v1.service;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.doer.erp.core.util.Constant;
import com.doer.erp.core.util.ReportUtil;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.dao.GetExamMarksheetReportByStudentIdV1Dao;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.entity.ExamResultMark;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.models.GetExamMarksheetReportByStudentIdV1Model;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.request.GetExamMarksheetReportByStudentIdV1Request;
import com.doer.erp.get.exam.markseet.report.by.student.id.v1.validator.GetExamMarksheetReportByStudentIdV1ValidatorService;
import com.doer.erp.report.model.InstituteReportModel;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
@Slf4j
public class GetExamMarksheetReportByStudentIdV1Service {
	@Autowired
	private ResourceLoader resourceLoader;
	
	@Autowired
	private GetExamMarksheetReportByStudentIdV1ValidatorService validatorService;

	@Autowired
	private GetExamMarksheetReportByStudentIdV1Dao dao;
	
	public void generatePdfFile(@RequestBody GetExamMarksheetReportByStudentIdV1Request request,
			OutputStream out) throws Exception {
		
		validatorService.validateGetExamRoutineByExamOidRequest(request);
		
		InstituteReportModel institute = dao.getInstituteInfo(request.getBody().getInstituteOid());
		
		GetExamMarksheetReportByStudentIdV1Model studentInfo = dao.loodExamResult(request);
		
		studentInfo.getResultMarksList().stream().distinct();
		
		BigDecimal totalGradePoint = studentInfo.getResultMarksList().stream().map(ExamResultMark:: getGradePoint)
				.reduce(BigDecimal.ZERO, BigDecimal::add).divide(BigDecimal.valueOf(studentInfo.getResultMarksList().size())).setScale(2, RoundingMode.HALF_UP);
		studentInfo.getResultMarksList().stream().findFirst().get().setTotalGradePoint(totalGradePoint);
		
		Map<String, Object> parameters = new HashMap<String, Object>();
		String reportPath = Constant.JASPER_REPORT_PATH + ReportUtil.EXAM_MARKSHIT_REPORT_FOLDER;
		try {
			parameters.put("studentInfo", studentInfo);
			parameters.put("resultMarksList", studentInfo.getResultMarksList());
			parameters.put("reportPath", reportPath);
			
			Resource resource = null;
			
			if (!request.getBody().getLang().isEmpty() && request.getBody().getLang().equals(Constant.ENGLISH)) {

				resource = resourceLoader.getResource(Constant.CLASS_PATH + reportPath + ReportUtil.EXAM_MARKSHIT_BY_STUDENT_ID_EN);

			} else if (!request.getBody().getLang().isEmpty() && request.getBody().getLang().equals(Constant.BANGLA)) {
				
				resource = resourceLoader.getResource(Constant.CLASS_PATH + reportPath  + ReportUtil.EXAM_MARKSHIT_BY_STUDENT_ID_EN);

			}
			JasperReport jasperReport = JasperCompileManager.compileReport(resource.getInputStream());
			JasperPrint print = JasperFillManager.fillReport(jasperReport, parameters,
					new JRBeanCollectionDataSource(Arrays.asList("NO LIST")));
			JasperExportManager.exportReportToPdfStream(print, out);
			
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.error("", e.getMessage());
		}
	}


}
